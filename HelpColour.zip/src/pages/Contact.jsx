import { Mail, Phone, MapPin, Send } from "lucide-react";
import {
  FaLinkedin,
  FaTwitter,
  FaFacebookF,
  FaInstagram,
} from "react-icons/fa";
import pageBg from "../assets/page-bg.png";

function Contact() {
  return (
    <div className="bg-[#020617] text-white">
      {/* Full Width Banner Section */}
      <div className="relative h-[200px] md:h-[350px] overflow-hidden group shadow-2xl">
        <img
          src={pageBg}
          alt="Contact Header"
          className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#020617]/20 to-[#020617]"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center space-y-4">
            <div className="h-1 w-20 bg-primary-400 mx-auto rounded-full" />
            <h2 className="text-white/20 text-6xl md:text-8xl font-black uppercase tracking-widest select-none">
              Contact
            </h2>
          </div>
        </div>
      </div>

      <div className="px-6 py-20 lg:px-16">
        <div className="max-w-6xl mx-auto space-y-16">
          <header className="space-y-6 text-center">
            <p className="text-primary-100 uppercase tracking-[0.35em] text-sm font-semibold">
              Contact Us
            </p>
            <h1 className="text-4xl font-extrabold sm:text-5xl">
              Let’s Discuss Your Project
            </h1>
            <p className="mx-auto max-w-3xl text-slate-400 leading-8 text-lg">
              Whether you are working on pharmaceutical, chemical, material
              science, or research-based projects, our team is ready to support
              your solid-state development requirements.
            </p>
          </header>

          <div className="grid gap-8 lg:grid-cols-[0.95fr_0.75fr]">
            <div className="space-y-6 rounded-2xl border border-primary-400/10 bg-primary-950/90 p-6 shadow-2xl">
              <div className="grid gap-5">
                <div className="flex items-center gap-5 rounded-3xl border border-primary-400/10 bg-slate-900/90 p-5">
                  <div className="flex h-14 w-14 items-center justify-center rounded-3xl bg-primary-400/10 text-primary-100">
                    <Mail size={24} />
                  </div>
                  <div>
                    <p className="text-sm uppercase tracking-[0.24em] text-primary-100">
                      Email
                    </p>
                    <p className="mt-2 text-slate-300">
                      contact@unitcelllabs.com
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-5 rounded-3xl border border-primary-400/10 bg-slate-900/90 p-5">
                  <div className="flex h-14 w-14 items-center justify-center rounded-3xl bg-primary-400/10 text-primary-100">
                    <Phone size={24} />
                  </div>
                  <div>
                    <p className="text-sm uppercase tracking-[0.24em] text-primary-100">
                      Phone
                    </p>
                    <p className="mt-2 text-slate-300">+91 8977770084</p>
                  </div>
                </div>
                <div className="flex items-center gap-5 rounded-3xl border border-primary-400/10 bg-slate-900/90 p-5">
                  <div className="flex h-14 w-14 items-center justify-center rounded-3xl bg-primary-400/10 text-primary-100">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <p className="text-sm uppercase tracking-[0.24em] text-primary-100">
                      Location
                    </p>
                    <p className="mt-2 text-slate-300">
                      Indian Institute of Technology Hyderabad, Kandi, Sangareddy,
                      Telangana-502885, India
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-primary-400/10">
                <p className="text-sm uppercase tracking-[0.24em] text-primary-100 mb-6">
                  Connect With Us
                </p>
                <div className="flex gap-4">
                  <a
                    href="#"
                    className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-400/10 text-primary-100 transition-all duration-300 hover:bg-primary-400 hover:text-slate-950"
                  >
                    <FaLinkedin size={20} />
                  </a>
                  <a
                    href="#"
                    className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-400/10 text-primary-100 transition-all duration-300 hover:bg-primary-400 hover:text-slate-950"
                  >
                    <FaTwitter size={20} />
                  </a>
                  <a
                    href="#"
                    className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-400/10 text-primary-100 transition-all duration-300 hover:bg-primary-400 hover:text-slate-950"
                  >
                    <FaFacebookF size={20} />
                  </a>
                  <a
                    href="#"
                    className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-400/10 text-primary-100 transition-all duration-300 hover:bg-primary-400 hover:text-slate-950"
                  >
                    <FaInstagram size={20} />
                  </a>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-primary-400/10 bg-primary-950/90 p-6 shadow-2xl">
              <h2 className="text-3xl font-semibold text-primary-100 mb-5">
                Send a Request
              </h2>
              <form className="space-y-6">
                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-300">
                    Name
                  </label>
                  <input
                    type="text"
                    placeholder="Enter your name"
                    className="w-full rounded-2xl border border-primary-400/20 bg-[#020617] px-5 py-3 text-slate-100 outline-none transition focus:border-primary-100"
                  />
                </div>
                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-300">
                    Company Name
                  </label>
                  <input
                    type="text"
                    placeholder="Enter your company name"
                    className="w-full rounded-2xl border border-primary-400/20 bg-[#020617] px-5 py-3 text-slate-100 outline-none transition focus:border-primary-100"
                  />
                </div>
                <div className="grid gap-6 sm:grid-cols-2">
                  <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                      Email Address
                    </label>
                    <input
                      type="email"
                      placeholder="Enter your email"
                      className="w-full rounded-2xl border border-primary-400/20 bg-[#020617] px-5 py-3 text-slate-100 outline-none transition focus:border-primary-100"
                    />
                  </div>
                  <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      placeholder="Enter your phone"
                      className="w-full rounded-2xl border border-primary-400/20 bg-[#020617] px-5 py-3 text-slate-100 outline-none transition focus:border-primary-100"
                    />
                  </div>
                </div>
                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-300">
                    Service Requirement
                  </label>
                  <select className="w-full rounded-2xl border border-primary-400/20 bg-[#020617] px-5 py-3 text-slate-100 outline-none transition focus:border-primary-100">
                    <option value="">Select a service requirement</option>
                    <option>Polymorph Screening</option>
                    <option>Salt Screening</option>
                    <option>Co-crystal Screening</option>
                    <option>Characterization & Analysis</option>
                    <option>Crystallization Development</option>
                    <option>Preformulation Studies</option>
                  </select>
                </div>
                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-300">
                    Message
                  </label>
                  <textarea
                    rows="5"
                    placeholder="Describe your project or inquiry"
                    className="w-full rounded-2xl border border-primary-400/20 bg-[#020617] px-5 py-3 text-slate-100 outline-none transition focus:border-primary-100"
                  />
                </div>
                <button className="inline-flex w-full items-center justify-center gap-3 rounded-2xl bg-primary-400 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-primary-100">
                  Send Request
                  <Send size={20} />
                </button>
              </form>
            </div>
          </div>
        </div>

        <div className="mt-20 max-w-7xl mx-auto overflow-hidden rounded-[2rem] border border-primary-400/10 shadow-2xl">
          <iframe
            title="Unit Cell Labs Location"
            src="https://www.google.com/maps?q=Indian+Institute+of+Technology+Hyderabad&output=embed"
            width="100%"
            height="300"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="w-full"
          ></iframe>
        </div>
      </div>
    </div>
  );
}

export default Contact;
